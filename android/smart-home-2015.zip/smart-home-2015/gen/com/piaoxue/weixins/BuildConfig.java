/** Automatically generated file. DO NOT MODIFY */
package com.piaoxue.weixins;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}